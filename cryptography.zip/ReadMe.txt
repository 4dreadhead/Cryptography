Текущая версия: 1.1.0

Для корректной работы распаковать папку application
Для запуска открыть файл application.exe

Вячеслав Жданов, гр. КИ18-01
Ссылка на проект:
https://github.com/4dreadhead/Cryptography