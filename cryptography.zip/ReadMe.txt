Текущая версия: 1.3.4

Для корректной работы распаковать папку application
Для запуска открыть файл application.exe

Вячеслав Жданов, гр. КИ18-01
Ссылка на проект:
https://github.com/4dreadhead/Cryptography